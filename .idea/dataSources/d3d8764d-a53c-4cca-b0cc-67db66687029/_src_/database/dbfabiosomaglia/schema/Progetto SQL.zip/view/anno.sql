CREATE VIEW anno AS SELECT release_country.date_year
   FROM ((("Progetto SQL".release
     JOIN "Progetto SQL".release_country ON ((release.id = release_country.release)))
     JOIN "Progetto SQL".country_area ON ((release_country.country = country_area.area)))
     JOIN "Progetto SQL".area ON (((country_area.area = area.id) AND ((area.name)::text = 'Italy'::text))));
