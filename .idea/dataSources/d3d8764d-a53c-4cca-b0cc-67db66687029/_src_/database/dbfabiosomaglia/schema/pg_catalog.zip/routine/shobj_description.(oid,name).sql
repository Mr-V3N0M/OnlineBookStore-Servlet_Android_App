create function pg_catalog.shobj_description(oid, name) returns text
LANGUAGE SQL
AS $$
select description from pg_catalog.pg_shdescription where objoid = $1 and classoid = (select oid from pg_catalog.pg_class where relname = $2 and relnamespace = 11)
$$;
