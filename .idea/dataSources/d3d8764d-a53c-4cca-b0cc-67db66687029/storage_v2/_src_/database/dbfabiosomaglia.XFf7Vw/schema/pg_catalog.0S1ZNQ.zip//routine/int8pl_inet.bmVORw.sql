create function pg_catalog.int8pl_inet(bigint, inet) returns inet
LANGUAGE SQL
AS $$
select $2 + $1
$$;
