CREATE VIEW temp AS SELECT release.id,
    count(release_country.country) AS area
   FROM ("Progetto SQL".release
     JOIN "Progetto SQL".release_country ON ((release.id = release_country.release)))
  GROUP BY release.id;
